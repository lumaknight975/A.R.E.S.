@echo off
REM ARES AI - Windows Launcher

echo.
echo ========================================
echo   ARES AI Threat Monitor
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt

echo.
echo Choose what to run:
echo.
echo 1. Generate skull.png (run once)
echo 2. Start Server (Terminal 1)
echo 3. Start UI (Terminal 2)
echo 4. Open Attack Map (in browser)
echo.

set /p choice="Enter choice (1-4): "

if "%choice%"=="1" (
    python generate_skull.py
) else if "%choice%"=="2" (
    python server.py
) else if "%choice%"=="3" (
    python main.py
) else if "%choice%"=="4" (
    start map.html
) else (
    echo Invalid choice
)

pause