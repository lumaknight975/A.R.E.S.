"""
ARES AI - Automatic Package Creator
Run this to create ares-ai-monitor.zip with all files
"""

import zipfile
import os
from pathlib import Path

def create_zip_package():
    """Create the complete ARES AI ZIP package"""
    
    # Define all files and their content
    files = {
        'server.py': '''"""
ARES AI - FastAPI Server
Handles threat reporting and data retrieval
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import datetime

app = FastAPI(title="ARES AI Server")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logs = []

@app.post("/report")
def report(data: dict):
    """Log a threat report"""
    data["time"] = str(datetime.datetime.now())
    logs.append(data)
    print(f"[SERVER] Threat: {data}")
    return {"ok": True, "total_threats": len(logs)}

@app.get("/threats")
def threats():
    """Retrieve all threat logs"""
    return logs

@app.get("/stats")
def stats():
    """Get threat statistics"""
    return {
        "total_threats": len(logs),
        "high_level": len([l for l in logs if l.get("level") == "HIGH"]),
        "low_level": len([l for l in logs if l.get("level") == "LOW"])
    }

@app.get("/health")
def health():
    """Health check endpoint"""
    return {"status": "ARES ONLINE", "version": "1.0"}

if __name__ == "__main__":
    import uvicorn
    print("🚀 ARES AI Server starting on http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)
''',

        'ares.py': '''"""
ARES AI Core Engine
Threat detection using machine learning
"""

import psutil
import pandas as pd
from sklearn.ensemble import IsolationForest
import requests
import time

SERVER = "http://127.0.0.1:8000"

class ARES:
    def __init__(self):
        self.model = IsolationForest(contamination=0.05, random_state=42)
        self.data = []
        self.trained = False

    def metrics(self):
        """Gather system metrics"""
        try:
            return {
                "cpu": psutil.cpu_percent(interval=0.1),
                "memory": psutil.virtual_memory().percent,
                "processes": len(psutil.pids()),
                "disk": psutil.disk_usage('/').percent
            }
        except Exception as e:
            print(f"[ERROR] Failed to gather metrics: {e}")
            return {"cpu": 0, "memory": 0, "processes": 0, "disk": 0}

    def train(self):
        """Train the anomaly detection model"""
        print("[ARES] 🧠 Training AI Model...")
        try:
            for i in range(30):
                m = self.metrics()
                self.data.append(m)
                print(f"[ARES] Training {i+1}/30... CPU: {m['cpu']}% MEM: {m['memory']}%")
                time.sleep(0.5)

            if len(self.data) > 0:
                df = pd.DataFrame(self.data)
                self.model.fit(df)
                self.trained = True
                print("[ARES] ✅ AI Model Ready!")
            else:
                print("[ARES] ⚠️ No data collected for training")
        except Exception as e:
            print(f"[ERROR] Training failed: {e}")

    def run(self, callback):
        """Main monitoring loop"""
        if not self.trained:
            print("[ARES] ⚠️ Model not trained, skipping monitoring")
            return

        print("[ARES] 🔍 Starting threat detection...")
        threat_count = 0
        
        while True:
            try:
                m = self.metrics()
                df_test = pd.DataFrame([m])
                score = self.model.decision_function(df_test)[0]

                if score < -0.2:
                    threat_count += 1
                    print(f"[ARES] ⚠️  THREAT DETECTED! (Score: {score:.3f})")
                    
                    try:
                        response = requests.post(SERVER + "/report", json={
                            "ip": "local",
                            "level": "HIGH",
                            "score": float(score),
                            "metrics": m
                        }, timeout=2)
                        if response.status_code == 200:
                            print(f"[ARES] ✅ Threat reported to server")
                    except Exception as e:
                        print(f"[ARES] ⚠️ Failed to report threat: {e}")

                    callback("HIGH")
                else:
                    callback("LOW")

                time.sleep(2)
            except Exception as e:
                print(f"[ERROR] In monitoring loop: {e}")
                callback("ERROR")
                time.sleep(2)
''',

        'network.py': '''"""
Network Monitoring Module
"""

try:
    from scapy.all import sniff, IP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

class NetworkMonitor:
    def __init__(self):
        self.count = {}
        self.packet_count = 0

    def process(self, packet):
        """Process packets"""
        try:
            if packet.haslayer(IP):
                ip = packet[IP].src
                self.count[ip] = self.count.get(ip, 0) + 1
                self.packet_count += 1

                if self.count[ip] > 100:
                    return ip
        except Exception as e:
            pass
        return None

    def start(self, callback):
        """Start network sniffing"""
        if not SCAPY_AVAILABLE:
            print("[WARNING] Network monitoring requires scapy")
            return

        print("[NETWORK] 🌐 Starting network monitoring...")
        try:
            def handler(packet):
                ip = self.process(packet)
                if ip:
                    print(f"[NETWORK] ⚠️ Suspicious activity from {ip}")
                    callback(ip)

            sniff(prn=handler, store=False)
        except PermissionError:
            print("[ERROR] Network monitoring requires admin/root privileges")
        except Exception as e:
            print(f"[ERROR] Network monitoring error: {e}")
''',

        'auth.py': '''"""
License Authentication Module
"""

LICENSE_KEY = "ARES-999-ULTRA"

def validate(key):
    """Validate license key"""
    return key == LICENSE_KEY

def get_license_info():
    """Get license information"""
    return {
        "version": "1.0",
        "licensed_to": "ARES AI User",
        "key": LICENSE_KEY,
        "status": "ACTIVE"
    }
''',

        'main.py': '''"""
ARES AI - Main UI Application
PySide6 Desktop Interface
"""

import sys
import threading
import time

from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, 
                                QLabel, QTextEdit, QPushButton)
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtCore import QTimer, Qt

from ares import ARES
from network import NetworkMonitor
from auth import validate, get_license_info

class UI(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.threat_level = "LOW"

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("ARES AI - Threat Monitor")
        self.setGeometry(100, 100, 1000, 700)
        self.setStyleSheet("""
            QWidget {
                background-color: #0a0a0a;
                color: #ff0000;
                font-family: 'Courier New';
            }
            QLabel {
                color: #ff0000;
            }
            QTextEdit {
                background-color: #1a1a1a;
                color: #00ff00;
                border: 2px solid #ff0000;
                padding: 5px;
            }
            QPushButton {
                background-color: #1a1a1a;
                color: #ff0000;
                border: 2px solid #ff0000;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2a2a2a;
            }
        """)

        main_layout = QVBoxLayout()

        # Header
        header_layout = QHBoxLayout()
        
        self.title = QLabel("ARES AI ONLINE")
        title_font = QFont("Arial", 24, QFont.Bold)
        self.title.setFont(title_font)
        header_layout.addWidget(self.title)

        # Skull Image
        self.skull = QLabel()
        pixmap = QPixmap("skull.png")
        if not pixmap.isNull():
            self.skull.setPixmap(pixmap.scaledToHeight(80, Qt.SmoothTransformation))
        else:
            self.skull.setText("⚠️ [skull.png not found]")
        self.skull.setMaximumWidth(100)
        header_layout.addStretch()
        header_layout.addWidget(self.skull)

        main_layout.addLayout(header_layout)

        # Threat Status
        status_layout = QHBoxLayout()
        
        self.threat_label = QLabel("THREAT STATUS:")
        self.threat_label.setFont(QFont("Arial", 12, QFont.Bold))
        status_layout.addWidget(self.threat_label)
        
        self.threat_display = QLabel("● LOW")
        threat_font = QFont("Arial", 16, QFont.Bold)
        self.threat_display.setFont(threat_font)
        self.threat_display.setStyleSheet("color: #00ff00;")
        status_layout.addWidget(self.threat_display)
        
        status_layout.addStretch()
        main_layout.addLayout(status_layout)

        # Logs
        log_label = QLabel("📋 SYSTEM LOGS:")
        log_label.setFont(QFont("Arial", 11, QFont.Bold))
        main_layout.addWidget(log_label)

        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setMinimumHeight(300)
        main_layout.addWidget(self.logs)

        # Control buttons
        button_layout = QHBoxLayout()
        
        self.clear_btn = QPushButton("Clear Logs")
        self.clear_btn.clicked.connect(self.logs.clear)
        button_layout.addWidget(self.clear_btn)
        
        self.quit_btn = QPushButton("Shutdown ARES")
        self.quit_btn.clicked.connect(self.shutdown)
        button_layout.addWidget(self.quit_btn)
        
        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

        # Animation timer
        self.opacity = 1.0
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        self.timer.start(100)

        self.log_message("[SYSTEM] ARES AI initialized", "info")

    def animate(self):
        """Glow animation effect"""
        self.opacity += 0.05
        if self.opacity > 1.3:
            self.opacity = 0.7
        self.setWindowOpacity(self.opacity)

    def update_threat(self, level):
        """Update threat level display"""
        self.threat_level = level
        
        if level == "HIGH":
            self.threat_display.setText("● HIGH")
            self.threat_display.setStyleSheet("color: #ff0000;")
            self.log_message(f"⚠️ THREAT DETECTED: {level}", "threat")
        else:
            self.threat_display.setText("● LOW")
            self.threat_display.setStyleSheet("color: #00ff00;")

    def log_message(self, message, msg_type="info"):
        """Add message to logs"""
        timestamp = time.strftime("%H:%M:%S")
        
        if msg_type == "threat":
            prefix = "🚨"
        elif msg_type == "network":
            prefix = "🌐"
        else:
            prefix = "ℹ️"
        
        formatted = f"[{timestamp}] {prefix} {message}"
        self.logs.append(formatted)

    def shutdown(self):
        """Shutdown the application"""
        self.log_message("ARES shutting down...", "info")
        sys.exit(0)

def run_app():
    """Main application runner"""
    # License check
    key = input("\\n🔐 Enter License Key: ")
    if not validate(key):
        print("❌ INVALID LICENSE KEY")
        sys.exit(1)
    
    print("✅ License validated!")
    license_info = get_license_info()
    print(f"📌 Licensed to: {license_info['licensed_to']}")
    print(f"📌 Status: {license_info['status']}\\n")

    # Create Qt application
    qt_app = QApplication(sys.argv)
    ui = UI()
    ui.show()

    # Initialize ARES
    ares = ARES()
    ui.log_message("Training AI model...", "info")
    ares.train()

    # AI monitoring thread
    def ai_loop():
        ares.run(ui.update_threat)

    # Network monitoring thread
    network = NetworkMonitor()
    def network_loop():
        try:
            network.start(lambda ip: ui.log_message(f"Network anomaly from {ip}", "network"))
        except Exception as e:
            ui.log_message(f"Network monitor error: {e}", "info")

    # Start threads
    ai_thread = threading.Thread(target=ai_loop, daemon=True)
    ai_thread.start()
    ui.log_message("AI monitoring started", "info")

    # Network monitoring option
    try:
        net_input = input("Enable network monitoring? (requires admin) (y/n): ").lower()
        if net_input == 'y':
            net_thread = threading.Thread(target=network_loop, daemon=True)
            net_thread.start()
            ui.log_message("Network monitoring started", "info")
    except:
        pass

    sys.exit(qt_app.exec())

if __name__ == "__main__":
    run_app()
''',

        'generate_skull.py': '''"""
Generate the skull.png image
Run this to create the skull image
"""

from PIL import Image, ImageDraw

def generate_skull():
    width, height = 400, 500
    image = Image.new('RGB', (width, height), color='black')
    draw = ImageDraw.Draw(image)

    skull_pattern = [
        "                                        ",
        "        111111111111111111111111        ",
        "      111111111111111111111111111111    ",
        "    11111111111111111111111111111111111 ",
        "   1111111111111111111111111111111111111",
        "   1111111111111111111111111111111111111",
        "   1111111000000000111000000000111111111",
        "   1111111000000000111000000000111111111",
        "   1111111000000000111000000000111111111",
        "   1111111000000000111000000000111111111",
        "   1111111111111111111111111111111111111",
        "   1111111111111111111111111111111111111",
        "   1111111111111111111111111111111111111",
        "   1111111111111111111111111111111111111",
        "    11111111111111111111111111111111111 ",
        "    11111111111111111111111111111111111 ",
        "    11111111111111111111111111111111111 ",
        "    11111111111111111111111111111111111 ",
        "    11111000000011111111000000011111111 ",
        "    11111000000011111111000000011111111 ",
        "    11111000000011111111000000011111111 ",
        "    11111111111111111111111111111111111 ",
        "    11111111111111111111111111111111111 ",
        "     1111111111111111111111111111111111 ",
        "     1111111111111111111111111111111111 ",
        "      111111111111111111111111111111111 ",
        "      111111111111111111111111111111111 ",
        "       11111111111111111111111111111111 ",
        "       11111111111111111111111111111111 ",
        "        1111111111111111111111111111111 ",
        "        1111111111000011111111111111111 ",
        "         111111111000011111111111111111 ",
        "         111111111111111111111111111111 ",
        "          11111111111111111111111111111 ",
        "          11111111111111111111111111111 ",
    ]

    pixel_size = 10
    for y, row in enumerate(skull_pattern):
        for x, pixel in enumerate(row):
            if pixel == '1':
                x1 = x * pixel_size
                y1 = y * pixel_size
                x2 = x1 + pixel_size
                y2 = y1 + pixel_size
                draw.rectangle([x1, y1, x2, y2], fill='#FF0000', outline='#CC0000')

    image = image.resize((400, 500), Image.Resampling.LANCZOS)
    image.save('skull.png')
    print("✅ skull.png generated successfully!")

if __name__ == "__main__":
    generate_skull()
''',

        'map.html': '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ARES Live Attack Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Courier New', monospace;
            background: #0a0a0a;
            color: #ff0000;
            overflow: hidden;
        }

        #header {
            background: #1a1a1a;
            border-bottom: 3px solid #ff0000;
            padding: 15px;
            text-align: center;
        }

        #header h1 {
            font-size: 28px;
            text-shadow: 0 0 10px #ff0000;
            margin-bottom: 5px;
        }

        #stats {
            display: flex;
            justify-content: space-around;
            margin-top: 10px;
            font-size: 12px;
        }

        .stat-item {
            padding: 5px 15px;
            border: 1px solid #ff0000;
            border-radius: 3px;
        }

        #map {
            height: calc(100vh - 120px);
            background: #000;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 10px #ff0000; }
            50% { box-shadow: 0 0 20px #ff0000, 0 0 30px #ff0000; }
            100% { box-shadow: 0 0 10px #ff0000; }
        }

        .popup-content {
            background: #1a1a1a;
            color: #00ff00;
            border: 1px solid #ff0000;
            padding: 10px;
            font-family: 'Courier New';
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div id="header">
        <h1>⚠️ ARES LIVE ATTACK MAP ⚠️</h1>
        <div id="stats">
            <div class="stat-item">Total Threats: <span id="total">0</span></div>
            <div class="stat-item">High Priority: <span id="high">0</span></div>
            <div class="stat-item">Last Update: <span id="lastupdate">Never</span></div>
        </div>
    </div>

    <div id="map"></div>

    <script>
        let map = L.map('map').setView([20, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        let markers = [];
        const SERVER = "http://127.0.0.1:8000";

        async function updateMap() {
            try {
                const response = await fetch(`${SERVER}/threats`);
                const threats = await response.json();

                markers.forEach(m => map.removeLayer(m));
                markers = [];

                threats.forEach((threat, index) => {
                    const lat = Math.random() * 140 - 70;
                    const lon = Math.random() * 360 - 180;

                    const circle = L.circleMarker([lat, lon], {
                        radius: 10,
                        fillColor: '#ff0000',
                        color: '#cc0000',
                        weight: 2,
                        opacity: 0.9,
                        fillOpacity: 0.8
                    }).addTo(map);

                    const popupContent = `
                        <div class="popup-content">
                            <strong>Threat #${index + 1}</strong><br>
                            IP: ${threat.ip}<br>
                            Level: ${threat.level}<br>
                            Time: ${threat.time}
                        </div>
                    `;

                    circle.bindPopup(popupContent);
                    markers.push(circle);
                });

                document.getElementById('total').textContent = threats.length;
                document.getElementById('high').textContent = threats.filter(t => t.level === 'HIGH').length;
                document.getElementById('lastupdate').textContent = new Date().toLocaleTimeString();

            } catch (error) {
                console.error('Error fetching threats:', error);
            }
        }

        setInterval(updateMap, 2000);
        updateMap();
    </script>
</body>
</html>
''',

        'requirements.txt': '''pyside6==6.6.0
psutil==5.9.6
scikit-learn==1.3.2
pandas==2.1.1
fastapi==0.104.1
uvicorn==0.24.0
requests==2.31.0
scapy==2.5.0
Pillow==10.1.0
''',

        'run.bat': '''@echo off
REM ARES AI - Windows Launcher

echo.
echo ========================================
echo   ARES AI Threat Monitor
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

echo Installing dependencies...
pip install -r requirements.txt

echo.
echo Choose what to run:
echo.
echo 1. Generate skull.png (run once)
echo 2. Start Server (Terminal 1)
echo 3. Start UI (Terminal 2)
echo 4. Open Attack Map (in browser)
echo.

set /p choice="Enter choice (1-4): "

if "%choice%"=="1" (
    python generate_skull.py
) else if "%choice%"=="2" (
    python server.py
) else if "%choice%"=="3" (
    python main.py
) else if "%choice%"=="4" (
    start map.html
) else (
    echo Invalid choice
)

pause
''',

        'run.sh': '''#!/bin/bash

echo ""
echo "========================================"
echo "  ARES AI Threat Monitor"
echo "========================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 not found. Please install Python 3.8+"
    exit 1
fi

echo "Installing dependencies..."
pip3 install -r requirements.txt

echo ""
echo "Choose what to run:"
echo ""
echo "1. Generate skull.png (run once)"
echo "2. Start Server (Terminal 1)"
echo "3. Start UI (Terminal 2)"
echo "4. Open Attack Map (in browser)"
echo ""

read -p "Enter choice (1-4): " choice

case $choice in
    1) python3 generate_skull.py ;;
    2) python3 server.py ;;
    3) python3 main.py ;;
    4) open map.html ;;
    *) echo "Invalid choice" ;;
esac
''',

        'SETUP.md': '''# ARES AI Setup Guide

## Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

## Installation Steps

### 1. Extract Files
Extract all files to a folder: `ares-ai-monitor/`

### 2. Install Dependencies
```bash
pip install -r requirements.txt