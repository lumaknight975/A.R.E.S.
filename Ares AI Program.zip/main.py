"""
ARES AI - Main UI Application
PySide6 Desktop Interface
"""

import sys
import threading
import time

from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, 
                                QLabel, QTextEdit, QPushButton, QLineEdit)
from PySide6.QtGui import QPixmap, QFont, QColor
from PySide6.QtCore import QTimer, Qt

from ares import ARES
from network import NetworkMonitor
from auth import validate, get_license_info

class UI(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.threat_level = "LOW"

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("ARES AI - Threat Monitor")
        self.setGeometry(100, 100, 1000, 700)
        self.setStyleSheet("""
            QWidget {
                background-color: #0a0a0a;
                color: #ff0000;
                font-family: 'Courier New';
            }
            QLabel {
                color: #ff0000;
            }
            QTextEdit {
                background-color: #1a1a1a;
                color: #00ff00;
                border: 2px solid #ff0000;
                padding: 5px;
            }
            QPushButton {
                background-color: #1a1a1a;
                color: #ff0000;
                border: 2px solid #ff0000;
                padding: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2a2a2a;
            }
        """)

        main_layout = QVBoxLayout()

        # Header
        header_layout = QHBoxLayout()
        
        self.title = QLabel("ARES AI ONLINE")
        title_font = QFont("Arial", 24, QFont.Bold)
        self.title.setFont(title_font)
        header_layout.addWidget(self.title)

        # Skull Image
        self.skull = QLabel()
        pixmap = QPixmap("skull.png")
        if not pixmap.isNull():
            self.skull.setPixmap(pixmap.scaledToHeight(80, Qt.SmoothTransformation))
        else:
            self.skull.setText("⚠️ [skull.png not found]")
        self.skull.setMaximumWidth(100)
        header_layout.addStretch()
        header_layout.addWidget(self.skull)

        main_layout.addLayout(header_layout)

        # Threat Status
        status_layout = QHBoxLayout()
        
        self.threat_label = QLabel("THREAT STATUS:")
        self.threat_label.setFont(QFont("Arial", 12, QFont.Bold))
        status_layout.addWidget(self.threat_label)
        
        self.threat_display = QLabel("● LOW")
        threat_font = QFont("Arial", 16, QFont.Bold)
        self.threat_display.setFont(threat_font)
        self.threat_display.setStyleSheet("color: #00ff00;")
        status_layout.addWidget(self.threat_display)
        
        status_layout.addStretch()
        main_layout.addLayout(status_layout)

        # Logs
        log_label = QLabel("📋 SYSTEM LOGS:")
        log_label.setFont(QFont("Arial", 11, QFont.Bold))
        main_layout.addWidget(log_label)

        self.logs = QTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setMinimumHeight(300)
        main_layout.addWidget(self.logs)

        # Control buttons
        button_layout = QHBoxLayout()
        
        self.clear_btn = QPushButton("Clear Logs")
        self.clear_btn.clicked.connect(self.logs.clear)
        button_layout.addWidget(self.clear_btn)
        
        self.quit_btn = QPushButton("Shutdown ARES")
        self.quit_btn.clicked.connect(self.shutdown)
        button_layout.addWidget(self.quit_btn)
        
        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

        # Animation timer
        self.opacity = 1.0
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        self.timer.start(100)

        self.log_message("[SYSTEM] ARES AI initialized", "info")

    def animate(self):
        """Glow animation effect"""
        self.opacity += 0.05
        if self.opacity > 1.3:
            self.opacity = 0.7
        self.setWindowOpacity(self.opacity)

    def update_threat(self, level):
        """Update threat level display"""
        self.threat_level = level
        
        if level == "HIGH":
            self.threat_display.setText("● HIGH")
            self.threat_display.setStyleSheet("color: #ff0000;")
            self.log_message(f"⚠️ THREAT DETECTED: {level}", "threat")
        else:
            self.threat_display.setText("● LOW")
            self.threat_display.setStyleSheet("color: #00ff00;")

    def log_message(self, message, msg_type="info"):
        """Add message to logs"""
        timestamp = time.strftime("%H:%M:%S")
        
        if msg_type == "threat":
            prefix = "🚨"
        elif msg_type == "network":
            prefix = "🌐"
        else:
            prefix = "ℹ️"
        
        formatted = f"[{timestamp}] {prefix} {message}"
        self.logs.append(formatted)

    def shutdown(self):
        """Shutdown the application"""
        self.log_message("ARES shutting down...", "info")
        sys.exit(0)

def run_app():
    """Main application runner"""
    # License check
    key = input("\n🔐 Enter License Key: ")
    if not validate(key):
        print("❌ INVALID LICENSE KEY")
        sys.exit(1)
    
    print("✅ License validated!")
    license_info = get_license_info()
    print(f"📌 Licensed to: {license_info['licensed_to']}")
    print(f"📌 Status: {license_info['status']}\n")

    # Create Qt application
    qt_app = QApplication(sys.argv)
    ui = UI()
    ui.show()

    # Initialize ARES
    ares = ARES()
    ui.log_message("Training AI model...", "info")
    ares.train()

    # AI monitoring thread
    def ai_loop():
        ares.run(ui.update_threat)

    # Network monitoring thread (optional)
    network = NetworkMonitor()
    def network_loop():
        try:
            network.start(lambda ip: ui.log_message(f"Network anomaly from {ip}", "network"))
        except Exception as e:
            ui.log_message(f"Network monitor error: {e}", "info")

    # Start threads
    ai_thread = threading.Thread(target=ai_loop, daemon=True)
    ai_thread.start()
    ui.log_message("AI monitoring started", "info")

    # Only start network monitoring if user wants it
    try:
        net_input = input("Enable network monitoring? (requires admin) (y/n): ").lower()
        if net_input == 'y':
            net_thread = threading.Thread(target=network_loop, daemon=True)
            net_thread.start()
            ui.log_message("Network monitoring started", "info")
    except:
        pass

    sys.exit(qt_app.exec())

if __name__ == "__main__":
    run_app()