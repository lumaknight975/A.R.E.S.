# 🔴 ARES AI - Advanced Threat Detection System

A comprehensive AI-powered threat monitoring and detection system with real-time visualization.

## Features

🤖 **Artificial Intelligence**
- Machine learning-based anomaly detection
- Real-time threat classification
- Adaptive threat scoring

📊 **System Monitoring**
- CPU usage tracking
- Memory monitoring
- Process analysis
- Disk usage monitoring

🌐 **Network Monitoring** (Optional)
- Real-time packet analysis
- Anomalous traffic detection
- Source IP tracking

🎨 **Interactive Dashboard**
- Real-time threat display
- System log viewer
- Animated threat indicators
- Professional dark theme

🗺️ **Live Attack Map**
- Global threat visualization
- Interactive Leaflet.js map
- Real-time threat markers
- Threat statistics

## Quick Start

1. **Install Python 3.8+**
2. **Extract files to `ares-ai-monitor/` folder**
3. **Run installer:**
   - Windows: `run.bat`
   - Linux/Mac: `bash run.sh`
4. **License Key:** `ARES-999-ULTRA`

## System Requirements

- **OS:** Windows, Linux, or macOS
- **Python:** 3.8 or higher
- **RAM:** 2GB minimum
- **Disk:** 500MB for dependencies
- **Network:** For API communication

## Components

| Component | Description |
|-----------|-------------|
| `server.py` | FastAPI backend server |
| `main.py` | PySide6 desktop UI |
| `ares.py` | AI threat detection engine |
| `network.py` | Network packet monitoring |
| `auth.py` | License validation |
| `map.html` | Interactive threat map |

## Architecture
