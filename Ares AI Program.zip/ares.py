"""
ARES AI Core Engine
Threat detection using machine learning
"""

import psutil
import pandas as pd
from sklearn.ensemble import IsolationForest
import requests
import time

SERVER = "http://127.0.0.1:8000"

class ARES:
    def __init__(self):
        self.model = IsolationForest(contamination=0.05, random_state=42)
        self.data = []
        self.trained = False

    def metrics(self):
        """Gather system metrics"""
        try:
            return {
                "cpu": psutil.cpu_percent(interval=0.1),
                "memory": psutil.virtual_memory().percent,
                "processes": len(psutil.pids()),
                "disk": psutil.disk_usage('/').percent
            }
        except Exception as e:
            print(f"[ERROR] Failed to gather metrics: {e}")
            return {"cpu": 0, "memory": 0, "processes": 0, "disk": 0}

    def train(self):
        """Train the anomaly detection model"""
        print("[ARES] 🧠 Training AI Model...")
        try:
            for i in range(30):
                m = self.metrics()
                self.data.append(m)
                print(f"[ARES] Training {i+1}/30... CPU: {m['cpu']}% MEM: {m['memory']}%")
                time.sleep(0.5)

            if len(self.data) > 0:
                df = pd.DataFrame(self.data)
                self.model.fit(df)
                self.trained = True
                print("[ARES] ✅ AI Model Ready!")
            else:
                print("[ARES] ⚠️ No data collected for training")
        except Exception as e:
            print(f"[ERROR] Training failed: {e}")

    def run(self, callback):
        """Main monitoring loop"""
        if not self.trained:
            print("[ARES] ⚠️ Model not trained, skipping monitoring")
            return

        print("[ARES] 🔍 Starting threat detection...")
        threat_count = 0
        
        while True:
            try:
                m = self.metrics()
                
                # Make prediction
                df_test = pd.DataFrame([m])
                score = self.model.decision_function(df_test)[0]

                # Threat detected if anomaly score is low (< -0.2)
                if score < -0.2:
                    threat_count += 1
                    print(f"[ARES] ⚠️  THREAT DETECTED! (Score: {score:.3f})")
                    
                    try:
                        response = requests.post(SERVER + "/report", json={
                            "ip": "local",
                            "level": "HIGH",
                            "score": float(score),
                            "metrics": m
                        }, timeout=2)
                        if response.status_code == 200:
                            print(f"[ARES] ✅ Threat reported to server")
                    except Exception as e:
                        print(f"[ARES] ⚠️ Failed to report threat: {e}")

                    callback("HIGH")
                else:
                    callback("LOW")

                time.sleep(2)
            except Exception as e:
                print(f"[ERROR] In monitoring loop: {e}")
                callback("ERROR")
                time.sleep(2)