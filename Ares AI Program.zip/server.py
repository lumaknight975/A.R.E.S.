"""
ARES AI - FastAPI Server
Handles threat reporting and data retrieval
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import datetime
import os

app = FastAPI(title="ARES AI Server")

# Enable CORS for the HTML map
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Store threat logs in memory
logs = []

@app.post("/report")
def report(data: dict):
    """Log a threat report"""
    data["time"] = str(datetime.datetime.now())
    logs.append(data)
    print(f"[SERVER] Threat: {data}")
    return {"ok": True, "total_threats": len(logs)}

@app.get("/threats")
def threats():
    """Retrieve all threat logs"""
    return logs

@app.get("/stats")
def stats():
    """Get threat statistics"""
    return {
        "total_threats": len(logs),
        "high_level": len([l for l in logs if l.get("level") == "HIGH"]),
        "low_level": len([l for l in logs if l.get("level") == "LOW"])
    }

@app.get("/health")
def health():
    """Health check endpoint"""
    return {"status": "ARES ONLINE", "version": "1.0"}

if __name__ == "__main__":
    import uvicorn
    print("🚀 ARES AI Server starting on http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)