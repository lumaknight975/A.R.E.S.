"""
Network Monitoring Module
Detects anomalous network activity
"""

try:
    from scapy.all import sniff, IP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("[WARNING] Scapy not available. Network monitoring disabled.")

class NetworkMonitor:
    def __init__(self):
        self.count = {}
        self.packet_count = 0

    def process(self, packet):
        """Process individual packets"""
        try:
            if packet.haslayer(IP):
                ip = packet[IP].src
                self.count[ip] = self.count.get(ip, 0) + 1
                self.packet_count += 1

                # Flag if too many packets from single IP
                if self.count[ip] > 100:
                    return ip
        except Exception as e:
            pass
        return None

    def start(self, callback):
        """Start network sniffing"""
        if not SCAPY_AVAILABLE:
            print("[WARNING] Network monitoring requires scapy. Install with: pip install scapy")
            return

        print("[NETWORK] 🌐 Starting network monitoring...")
        try:
            def handler(packet):
                ip = self.process(packet)
                if ip:
                    print(f"[NETWORK] ⚠️ Suspicious activity from {ip}")
                    callback(ip)

            sniff(prn=handler, store=False)
        except PermissionError:
            print("[ERROR] Network monitoring requires admin/root privileges")
        except Exception as e:
            print(f"[ERROR] Network monitoring error: {e}")