async function login() {
  const username = document.getElementById("user").value;
  const password = document.getElementById("pass").value;

  const res = await fetch("http://localhost:5000/login", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({username,password})
  });

  const data = await res.json();

  if(data.status==="ok"){
    document.getElementById("login").style.display="none";
    document.getElementById("app").style.display="block";
  } else {
    alert("Access denied");
  }
}

function typeText(text){
  let i=0;
  const chat=document.getElementById("chat");
  const div=document.createElement("div");
  chat.appendChild(div);

  const interval=setInterval(()=>{
    div.innerHTML+=text[i];
    i++;
    if(i>=text.length) clearInterval(interval);
  },15);
}

async function send(){
  const input=document.getElementById("input").value;

  const res=await fetch("http://localhost:5000/command",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({input})
  });

  const data=await res.json();

  document.getElementById("chat").innerHTML+=`<div>YOU: ${input}</div>`;
  typeText(`ARK: ${data.response}`);
}
