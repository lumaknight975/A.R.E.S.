from flask import Flask, request, jsonify

app = Flask(__name__)

USERNAME = "admin"
PASSWORD = "ark123"

def ask_ai(prompt):
    try:
        import requests
        r = requests.post("http://localhost:11434/api/generate",
                          json={"model":"llama3","prompt":prompt})
        return r.json().get("response","...")
    except:
        return "AI offline"

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    if data.get("username") == USERNAME and data.get("password") == PASSWORD:
        return jsonify({"status":"ok"})
    return jsonify({"status":"fail"})

@app.route('/command', methods=['POST'])
def command():
    data = request.json
    response = ask_ai(data.get("input"))
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(port=5000)
