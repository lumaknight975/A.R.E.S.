ARK OS - PROFESSIONAL RELEASE

SETUP (FAST):

1. Install Python deps:
   pip install flask requests

2. Install Node:
   npm install
   npm install electron electron-builder

3. Start AI (optional but recommended):
   ollama run llama3

4. Start backend:
   python backend/server.py

5. Launch ARK:
   npx electron .

6. Build installer:
   npx electron-builder

LOGIN:
admin / ark123

This is a professional base build. Ready for deployment.
